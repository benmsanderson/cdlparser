import setuptools

setuptools.setup(
    name="CDLparser",
    version="0.21",
    author="Ben Sanderson",
    description="A python netcdf CDF parser",
    packages=["cdlparser"]
    )
