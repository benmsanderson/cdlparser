# cdlparser
Python 3 CDL parser for netcdf
